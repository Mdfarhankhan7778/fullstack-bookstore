import React from 'react'

function Users() {
  return (
    <div>
      User
    </div>
  )
}

export default Users
