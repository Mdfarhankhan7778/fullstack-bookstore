import React from 'react'

function AdminSignup() {
  return (
    <div>
      Hello signUp Admin
    </div>
  )
}

export default AdminSignup
